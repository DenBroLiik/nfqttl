# Nfqttl Eclipse FastPath 4.1 — developer notes

## Architecture

```text
service.sh -> nfqttl daemon
                  |-- NETLINK_ROUTE watcher
                  |-- atomic iptables/ip6tables chain manager
                  |-- Android tether offload watchdog
                  |-- kernel TTL/HL probe
                  `-- NFQUEUE fallback workers (only when needed)

control.sh -> nfqttl status|start|stop|restart
```

## Preferred data path

The `seventeen` Eclipse tree already contains `net/netfilter/xt_HL.c`. Its Kconfig symbol is `CONFIG_NETFILTER_XT_TARGET_HL`, and it implements both the IPv4 `TTL` target and IPv6 `HL` target.

Therefore the preferred design is not another custom netfilter hook. Build `xt_HL` into the kernel and keep Android-specific interface/routing policy in userspace.

## NFQUEUE fallback

Fallback workers bind separate `NETLINK_NETFILTER` sockets for queues `6464..`.

Defaults:

- workers: 4
- queue maxlen: 4096
- receive socket request: 8 MiB
- userspace receive datagram: 256 KiB..1 MiB
- FAIL_OPEN + GSO requested; flags degrade gracefully if the kernel rejects them
- watchdog: 500 ms

The worker only changes IPv4 TTL and recalculates the IPv4 header checksum. TCP/UDP payload is not modified.

## Firewall updates

Stable hooks are `nfqttl_v40h` / `nfqttl6_v40h`; leaf chains alternate A/B. New rules are populated before replacing rule 1 of the stable hook. This avoids partially-built rulesets during route changes.

## Offload

Android tether hardware/BPF offload is disabled when requested and its previous value is ownership-tracked. v4.1 periodically re-applies the requested disabled state because Connectivity may rewrite these settings during tether lifecycle changes.

## Validation

Host, when Rust is installed:

```sh
cargo test
cargo clippy --all-targets -- -D warnings
./src/build.sh
```

Kernel:

```sh
git apply kernel/0001-stone-enable-ipv4-ipv6-hoplimit.patch
# build Eclipse normally
grep -E '^CONFIG_(NETFILTER_ADVANCED|NETFILTER_XT_TARGET_HL)=' <generated .config>
```

Phone:

- kernel backend selected;
- no unexpected NFQUEUE rows in kernel mode;
- tether route changes keep hook counters increasing;
- NFQUEUE fallback shows zero kernel/userspace drops under sustained load;
- offload remains disabled while the service owns it and is restored on stop.
