# Nfqttl Eclipse FastPath 4.1.0

Версия для Xiaomi `stone` (`moonstone/sunstone`), RisingOS и Eclipse Kernel.

Главная идея v4.1: **kernel-first**. Если в Eclipse включён штатный `xt_HL`, весь IPv4 TTL / IPv6 Hop Limit меняется прямо в ядре. Rust daemon остаётся control-plane: определяет tether/upstream интерфейсы, атомарно меняет правила, следит за route events и восстанавливает состояние. NFQUEUE используется только как fallback.

## Почему это лучше

### Kernel backend (рекомендуется)

```text
forwarded packet
      |
      v
iptables/ip6tables mangle
      |
      v
xt_HL (kernel)
      |
      v
packet continues
```

Нет копирования пакетов в userspace, нет очереди NFQUEUE и нет зависимости throughput от Rust worker.

Для Eclipse `seventeen` нужен:

```text
CONFIG_NETFILTER_ADVANCED=y
CONFIG_NETFILTER_XT_TARGET_HL=y
```

Патч: `kernel/0001-stone-enable-ipv4-ipv6-hoplimit.patch`.

Важно: в этом kernel tree IPv4 `TTL` и IPv6 `HL` предоставляет именно `CONFIG_NETFILTER_XT_TARGET_HL`. Старые `CONFIG_IP_NF_TARGET_TTL` / `CONFIG_IP6_NF_TARGET_HL` для этого дерева не нужны.

### Hardened NFQUEUE fallback

Если kernel target недоступен, v4.1 использует Rust NFQUEUE:

- до 8 workers;
- `--queue-balance`;
- `NFQA_CFG_F_GSO` + `NFQA_CFG_F_FAIL_OPEN` с автоматическим compatibility fallback;
- queue maxlen по умолчанию `4096` вместо `1024`;
- netlink receive buffer `8 MiB` с попыткой `SO_RCVBUFFORCE`;
- receive datagram buffer 256 KiB..1 MiB;
- watchdog 500 ms;
- backlog/stall/drop diagnostics;
- автоматическое снижение количества workers после повторяющихся сбоев.

## Stability changes v4.1

- xtables lock wait увеличен с 2 до 5 секунд — меньше ложных recovery при одновременной работе Android tethering.
- Android tether hardware/BPF offload повторно проверяется примерно каждые 10 секунд, если `DISABLE_OFFLOAD=1`.
- `COOLDOWN` по умолчанию уменьшен до 1 секунды.
- route/link/address changes по-прежнему приходят через `NETLINK_ROUTE`.
- firewall leaf chains меняются A/B: новая цепочка полностью строится до переключения stable hook.

## config.conf

```sh
TTL=64
BACKEND=auto
WORKERS=4
DOWNSTREAMS=""
UPSTREAMS=""
DISABLE_OFFLOAD=1
IPV6_MODE=auto
IPV6_HL=64
MAX_FAILURES=6
COOLDOWN=1
QUEUE_MAXLEN=4096
RCVBUF_MB=8
MAX_BACKLOG=3072
STALL_LIMIT=3
WATCHDOG_MS=500
```

Для твоего Eclipse оставляй `BACKEND=auto`. После включения `CONFIG_NETFILTER_XT_TARGET_HL=y` должен автоматически выбираться `kernel`.

## Проверка kernel fast path

После прошивки нового ядра и перезагрузки:

```sh
su -c '/data/adb/modules/nfqttl/nfqttl status'
```

Ожидается:

```text
Backend:
kernel
```

В kernel режиме NFQUEUE workers для data path не используются.

## Сборка Rust binary

```sh
./src/build.sh
```

Нужен Rust target `aarch64-unknown-linux-musl`. Скрипт создаёт статический ARM64 binary и затем install ZIP.

## Что тестировать на телефоне

1. hotspot + один клиент: ping, speed test, большие скачивания;
2. 2-3 клиента одновременно;
3. переключение LTE/5G и `rmnet_data*`;
4. Wi-Fi tether / USB tether / Bluetooth tether (если используешь);
5. suspend/resume;
6. звонок/VoWiFi во время hotspot;
7. `status` — kernel drops/userspace drops должны быть 0 в NFQUEUE fallback;
8. после kernel patch `Backend: kernel` должен оставаться стабильным при смене маршрута.

## Kernel integration

Подробно: `kernel/README_KERNEL.md`.
