# Eclipse stone kernel integration (recommended)

For `bittencourtjulival/eclipse_kernel_xiaomi_stone`, branch `seventeen`, the best data path is the kernel's existing `xt_HL` target.

That one target provides both:

- IPv4 `TTL --ttl-set ...`
- IPv6 `HL --hl-set ...`

Do **not** add a second custom packet hook unless there is a measured reason. The stock `net/netfilter/xt_HL.c` already edits the packet inside the kernel and avoids NFQUEUE/userspace copies entirely.

## Required defconfig

```text
CONFIG_NETFILTER=y
CONFIG_NETFILTER_ADVANCED=y
CONFIG_NETFILTER_XT_TARGET_HL=y
CONFIG_IP_NF_MANGLE=y
CONFIG_IP6_NF_MANGLE=y
```

`stone_defconfig` already has NETFILTER + IPv4/IPv6 mangle. Apply the included patch to add the missing two options:

```sh
git apply /path/to/kernel/0001-stone-enable-ipv4-ipv6-hoplimit.patch
```

After generating `.config`, verify:

```sh
grep -E '^CONFIG_(NETFILTER_ADVANCED|NETFILTER_XT_TARGET_HL)=' .config
```

Both should be `=y`.

## Why this is better than moving everything into the kernel

Android decides tether interfaces/upstreams dynamically (`wlan*`, `rndis*`, `ncm*`, `bnep*`, `rmnet_data*`, VPN routes, etc.). Keeping interface discovery and rule replacement in the small Rust supervisor is safer than hardcoding Android policy in a kernel hook.

The resulting split is:

```text
Android routes/tether changes
        |
        v
Rust supervisor (control plane only)
        |
        +--> iptables/ip6tables rules
                    |
                    v
             xt_HL in kernel
          (TTL/HL data fast path)
```

NFQUEUE is then only an emergency compatibility fallback when the kernel target cannot be installed.

## Expected status after flashing the rebuilt kernel

```text
Backend:
kernel
NFQUEUE workers:
1
```

There should be no active NFQUEUE rows for normal IPv4 tether traffic. Packet rewriting is done by `xt_HL` in kernel space.
